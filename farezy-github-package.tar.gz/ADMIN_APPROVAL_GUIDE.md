# Admin Partner Approval Guide

## How to Approve/Reject Taxi Companies

### Step 1: Access Admin Dashboard
1. Navigate to `/admin-dashboard` in your browser
2. You'll see a list of all partner applications with their status

### Step 2: Review Application Details
Each application shows:
- **Company Information**: Name, contact details, address
- **Fleet Details**: Number of vehicles, service types offered
- **Pricing**: Base rates and per-km charges
- **Licensing**: Business license and insurance details
- **Status**: Pending, Approved, or Rejected

### Step 3: Make a Decision
For each application, you can:

#### To APPROVE a company:
1. Click the **"Review"** button next to the application
2. Select **"Approve"** from the status dropdown
3. Add admin notes (optional but recommended)
   - Example: "Good application with valid documentation. Fleet size adequate for operating area."
4. Click **"Submit Review"**

#### To REJECT a company:
1. Click the **"Review"** button next to the application
2. Select **"Reject"** from the status dropdown  
3. Add admin notes explaining the reason
   - Example: "Missing valid insurance documentation. Please reapply with proper coverage."
4. Click **"Submit Review"**

### Step 4: What Happens After Approval
Once approved, the taxi company:
1. Receives approval notification (email would be sent in production)
2. Gets access to the Partner Portal at `/partner-portal`
3. Can start managing their fleet and receiving ride requests
4. Can add drivers and vehicles through their portal

### Step 5: What Happens After Rejection
If rejected, the company:
1. Receives rejection notification with admin notes
2. Can address the issues mentioned in admin notes
3. Can reapply by submitting a new partner application

## Current Test Data
There should be at least one test application in the system. If not, you can:
1. Go to `/partner-signup` to create a test application
2. Fill out the form with sample taxi company data
3. Submit the application
4. Return to admin dashboard to approve it

## Quick Test Process
1. Visit `http://localhost:5000/partner-signup`
2. Create a test taxi company application
3. Visit `http://localhost:5000/admin-dashboard`
4. Approve the test application
5. Visit `http://localhost:5000/partner-portal` to see the approved company's portal

## API Endpoints for Admin Actions
- **GET** `/api/partner-applications` - List all applications
- **GET** `/api/partner-applications/:id` - Get specific application
- **PUT** `/api/partner-applications/:id/review` - Approve/reject application
  ```json
  {
    "status": "approved", // or "rejected"
    "adminNotes": "Optional admin comments"
  }
  ```

The system is now fully functional for taxi company onboarding and approval!