# How to Add Drivers to Receive Bookings

## For Drivers to Connect and Receive Bookings:

### Step 1: Access Driver App
1. Go to **https://farezydriver.replit.app**
2. This is the driver interface where drivers log in and manage rides

### Step 2: Driver Registration Process
Drivers need to register through the WebSocket connection by sending:
```javascript
{
  type: 'register',
  data: { 
    userType: 'driver', 
    driverId: 'unique_driver_id',
    driverName: 'Driver Name',
    vehicleInfo: 'Car details'
  }
}
```

### Step 3: Driver Goes Online
Once registered, the driver needs to:
1. Set status to "online" in the driver app
2. Be connected to the WebSocket at farezydriver.replit.app/ws
3. Listen for incoming booking_request messages

### Step 4: Receiving Bookings
When a passenger books a ride:
1. Booking gets sent to all connected drivers with userType: 'driver'
2. Driver receives the booking_request with passenger details
3. Driver can accept or decline the booking
4. Response gets sent back to the passenger

## Quick Test Setup:

### Option 1: Use Driver Dashboard (Recommended)
1. **Open Driver App**: Go to https://farezydriver.replit.app
2. **Go Online**: Click "Go Online" button to set status to online
3. **Wait for Notifications**: The app automatically connects to WebSocket
4. **Receive Booking**: When a booking comes in, you'll see a yellow notification with:
   - Passenger name and phone
   - Pickup and destination addresses
   - Estimated fare in £
   - **Accept** and **Decline** buttons
5. **Accept/Decline**: Click the green Accept or red Decline button
6. **Response Sent**: Your response goes back to the passenger automatically

### Option 2: Manual Test Driver
Open browser console on farezydriver.replit.app and run:
```javascript
const driverWs = new WebSocket('wss://farezydriver.replit.app/ws');
driverWs.onopen = () => {
  driverWs.send(JSON.stringify({
    type: 'register',
    data: { userType: 'driver', driverId: 'test_driver_001' }
  }));
};
driverWs.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Driver received:', data);
  if (data.type === 'booking_request') {
    alert('New booking from: ' + data.data.passengerName);
  }
};
```

### Complete Test Flow:
1. **Driver**: Open https://farezydriver.replit.app and go online
2. **Passenger**: Use the booking form on your passenger app
3. **Driver**: See notification popup with Accept/Decline buttons
4. **Driver**: Click Accept or Decline
5. **Passenger**: Get instant response about driver decision

## Current Status:
- Passenger app: ✅ Ready to send bookings
- Driver app WebSocket: ✅ Ready to receive bookings
- Message routing: ✅ Working (forwards to 0 drivers currently)

**Next step**: Connect at least one driver to start receiving the booking requests.