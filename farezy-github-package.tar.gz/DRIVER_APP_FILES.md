# Farezy Driver App - Complete File Structure

## 1. package.json
```json
{
  "name": "farezy-driver-app",
  "version": "1.0.0",
  "description": "Farezy Driver Mobile App - Dedicated interface for taxi drivers",
  "type": "module",
  "scripts": {
    "dev": "vite --port 5001",
    "build": "tsc && vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "wouter": "^3.0.0",
    "@tanstack/react-query": "^5.17.0",
    "lucide-react": "^0.263.1",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.0.0",
    "tailwind-merge": "^1.14.0",
    "framer-motion": "^10.16.0",
    "date-fns": "^2.30.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.37",
    "@types/react-dom": "^18.2.15",
    "@vitejs/plugin-react": "^4.1.1",
    "autoprefixer": "^10.4.16",
    "postcss": "^8.4.31",
    "tailwindcss": "^3.3.5",
    "tailwindcss-animate": "^1.0.7",
    "typescript": "^5.2.2",
    "vite": "^5.0.0"
  }
}
```

## 2. vite.config.ts
```typescript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src")
    },
  },
  server: {
    port: 5001,
    proxy: {
      '/api': {
        target: 'https://farezy-co-uk.replit.app',
        changeOrigin: true,
      }
    }
  }
})
```

## 3. tailwind.config.js
```javascript
/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}
```

## 4. index.html
```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1" />
    <title>Farezy Driver - Your Partner Dashboard</title>
    <meta name="description" content="Farezy Driver App - Manage your bookings, track rides, and grow your taxi business with our partner platform." />
    
    <!-- PWA Meta Tags -->
    <meta name="theme-color" content="#10b981" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="default" />
    <meta name="apple-mobile-web-app-title" content="Farezy Driver" />
    <meta name="mobile-web-app-capable" content="yes" />
    
    <!-- Open Graph tags -->
    <meta property="og:title" content="Farezy Driver - Partner Dashboard" />
    <meta property="og:description" content="Manage your taxi bookings and grow your business with Farezy's partner platform" />
    <meta property="og:type" content="website" />
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

## 5. src/main.tsx
```typescript
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
```

## 6. src/index.css
```css
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    --background: 0 0% 100%;
    --foreground: 222.2 84% 4.9%;
    --card: 0 0% 100%;
    --card-foreground: 222.2 84% 4.9%;
    --popover: 0 0% 100%;
    --popover-foreground: 222.2 84% 4.9%;
    --primary: 142.1 76.2% 36.3%;
    --primary-foreground: 355.7 100% 97.3%;
    --secondary: 210 40% 96%;
    --secondary-foreground: 222.2 84% 4.9%;
    --muted: 210 40% 96%;
    --muted-foreground: 215.4 16.3% 46.9%;
    --accent: 210 40% 96%;
    --accent-foreground: 222.2 84% 4.9%;
    --destructive: 0 84.2% 60.2%;
    --destructive-foreground: 210 40% 98%;
    --border: 214.3 31.8% 91.4%;
    --input: 214.3 31.8% 91.4%;
    --ring: 142.1 76.2% 36.3%;
    --radius: 0.5rem;
  }

  .dark {
    --background: 222.2 84% 4.9%;
    --foreground: 210 40% 98%;
    --card: 222.2 84% 4.9%;
    --card-foreground: 210 40% 98%;
    --popover: 222.2 84% 4.9%;
    --popover-foreground: 210 40% 98%;
    --primary: 142.1 70.6% 45.3%;
    --primary-foreground: 144.9 80.4% 10%;
    --secondary: 217.2 32.6% 17.5%;
    --secondary-foreground: 210 40% 98%;
    --muted: 217.2 32.6% 17.5%;
    --muted-foreground: 215 20.2% 65.1%;
    --accent: 217.2 32.6% 17.5%;
    --accent-foreground: 210 40% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 210 40% 98%;
    --border: 217.2 32.6% 17.5%;
    --input: 217.2 32.6% 17.5%;
    --ring: 142.1 70.6% 45.3%;
  }
}

@layer base {
  * {
    @apply border-border;
  }
  body {
    @apply bg-background text-foreground;
  }
}

/* Driver app specific styles */
.driver-gradient {
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
}

.status-online {
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
}

.status-offline {
  background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
}

.status-busy {
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
}
```

## Instructions for Setup:

1. Create a new React + Vite Repl on Replit
2. Replace all template files with the code above
3. Create the folder structure: `src/pages/` and `src/components/`
4. Add the remaining page components (I can provide those next)
5. Run `npm install` to install dependencies
6. The app will be accessible at your new Repl's URL

## 7. src/App.tsx
```typescript
import { Switch, Route } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState } from "react";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import Bookings from "./pages/Bookings";
import Earnings from "./pages/Earnings";
import Profile from "./pages/Profile";
import Navigation from "./components/Navigation";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [driverInfo, setDriverInfo] = useState(null);

  if (!isAuthenticated) {
    return (
      <QueryClientProvider client={queryClient}>
        <Login onLogin={setIsAuthenticated} setDriverInfo={setDriverInfo} />
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-md mx-auto bg-white min-h-screen shadow-xl">
          <Switch>
            <Route path="/" component={() => <Dashboard driverInfo={driverInfo} />} />
            <Route path="/bookings" component={() => <Bookings driverInfo={driverInfo} />} />
            <Route path="/earnings" component={() => <Earnings driverInfo={driverInfo} />} />
            <Route path="/profile" component={() => <Profile driverInfo={driverInfo} setAuth={setIsAuthenticated} />} />
          </Switch>
          <Navigation />
        </div>
      </div>
    </QueryClientProvider>
  );
}

export default App;
```

## 8. src/components/Navigation.tsx
```typescript
import { useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Calendar, 
  PoundSterling, 
  User 
} from "lucide-react";

export default function Navigation() {
  const [location, setLocation] = useLocation();

  // Don't show navigation on main dashboard - it has its own layout
  if (location === '/') {
    return null;
  }

  const navItems = [
    { 
      path: '/', 
      icon: LayoutDashboard, 
      label: 'Map',
      active: location === '/'
    },
    { 
      path: '/bookings', 
      icon: Calendar, 
      label: 'Bookings',
      active: location === '/bookings'
    },
    { 
      path: '/earnings', 
      icon: PoundSterling, 
      label: 'Earnings',
      active: location === '/earnings'
    },
    { 
      path: '/profile', 
      icon: User, 
      label: 'Profile',
      active: location === '/profile'
    }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-30">
      <div className="max-w-md mx-auto">
        <div className="flex">
          {navItems.map((item) => (
            <button
              key={item.path}
              onClick={() => setLocation(item.path)}
              className={`flex-1 py-3 px-2 flex flex-col items-center gap-1 ${
                item.active 
                  ? 'text-green-600' 
                  : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
```

## 9. src/pages/Dashboard.tsx
```typescript
import { useState } from "react";
import { 
  Menu, 
  Search,
  BarChart3,
  Settings
} from "lucide-react";

interface DashboardProps {
  driverInfo: any;
}

export default function Dashboard({ driverInfo }: DashboardProps) {
  const [status, setStatus] = useState<'offline' | 'online' | 'busy'>('offline');
  const [todayEarnings] = useState(45.50);

  const toggleStatus = () => {
    if (status === 'offline') {
      setStatus('online');
    } else if (status === 'online') {
      setStatus('offline');
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'offline': return "You're offline";
      case 'online': return "You're online";
      case 'busy': return "On a trip";
      default: return "You're offline";
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'offline': return 'bg-gray-500';
      case 'online': return 'bg-green-500';
      case 'busy': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="relative h-screen w-full overflow-hidden">
      {/* Map Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-100 via-gray-100 to-green-100">
        {/* Simplified map pattern */}
        <div className="absolute inset-0 opacity-30">
          <svg className="w-full h-full" viewBox="0 0 400 800">
            {/* Road lines */}
            <path d="M50 0 L50 800" stroke="#ddd" strokeWidth="2" />
            <path d="M150 0 L150 800" stroke="#ddd" strokeWidth="2" />
            <path d="M250 0 L250 800" stroke="#ddd" strokeWidth="2" />
            <path d="M350 0 L350 800" stroke="#ddd" strokeWidth="2" />
            <path d="M0 100 L400 100" stroke="#ddd" strokeWidth="2" />
            <path d="M0 200 L400 200" stroke="#ddd" strokeWidth="2" />
            <path d="M0 300 L400 300" stroke="#ddd" strokeWidth="2" />
            <path d="M0 400 L400 400" stroke="#ddd" strokeWidth="2" />
            <path d="M0 500 L400 500" stroke="#ddd" strokeWidth="2" />
            <path d="M0 600 L400 600" stroke="#ddd" strokeWidth="2" />
            <path d="M0 700 L400 700" stroke="#ddd" strokeWidth="2" />
            
            {/* Green areas (parks) */}
            <circle cx="100" cy="150" r="30" fill="#a7f3d0" opacity="0.7" />
            <circle cx="300" cy="250" r="40" fill="#a7f3d0" opacity="0.7" />
            <circle cx="80" cy="450" r="25" fill="#a7f3d0" opacity="0.7" />
            
            {/* Blue areas (water) */}
            <ellipse cx="200" cy="350" rx="60" ry="30" fill="#bfdbfe" opacity="0.7" />
            <ellipse cx="120" cy="600" rx="40" ry="20" fill="#bfdbfe" opacity="0.7" />
          </svg>
        </div>
      </div>

      {/* Top Header */}
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between p-4">
        <button className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center">
          <Menu className="w-6 h-6 text-gray-700" />
        </button>
        
        <div className="bg-black rounded-full px-4 py-2 shadow-lg">
          <span className="text-white font-semibold text-lg">£{todayEarnings.toFixed(2)}</span>
        </div>
        
        <button className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center">
          <Search className="w-6 h-6 text-gray-700" />
        </button>
      </div>

      {/* Current Location Indicator */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10">
        <div className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center border-4 border-blue-500">
          <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
        </div>
      </div>

      {/* Right Side Controls */}
      <div className="absolute right-4 top-1/2 transform -translate-y-1/2 z-10 space-y-3">
        <button className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center">
          <div className="w-6 h-6 bg-gray-400 rounded-full"></div>
        </button>
        <button className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center">
          <BarChart3 className="w-6 h-6 text-gray-700" />
        </button>
      </div>

      {/* Central GO Button */}
      <div className="absolute bottom-32 left-1/2 transform -translate-x-1/2 z-20">
        <button
          onClick={toggleStatus}
          className={`w-24 h-24 rounded-full shadow-xl flex items-center justify-center transition-all duration-300 ${
            status === 'offline' 
              ? 'bg-blue-500 hover:bg-blue-600' 
              : status === 'online'
              ? 'bg-green-500 hover:bg-green-600'
              : 'bg-yellow-500 hover:bg-yellow-600'
          }`}
        >
          <span className="text-white text-2xl font-bold">GO</span>
        </button>
      </div>

      {/* Bottom Status Bar */}
      <div className="absolute bottom-0 left-0 right-0 z-20">
        <div className="bg-white border-t border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full ${getStatusColor()}`}></div>
              <span className="text-gray-700 font-medium">{getStatusText()}</span>
            </div>
            <button>
              <Settings className="w-6 h-6 text-gray-400" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
```

## 10. src/pages/Login.tsx
```typescript
import { useState } from "react";
import { Car, LogIn, Eye, EyeOff } from "lucide-react";

interface LoginProps {
  onLogin: (authenticated: boolean) => void;
  setDriverInfo: (info: any) => void;
}

export default function Login({ onLogin, setDriverInfo }: LoginProps) {
  const [credentials, setCredentials] = useState({
    email: "",
    password: ""
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    try {
      // Demo mode - allow any credentials for testing
      if (credentials.email && credentials.password) {
        const demoDriver = {
          id: 1,
          name: "John Driver",
          email: credentials.email,
          vehicle: "Toyota Prius - ABC123",
          company: "Demo Taxi Co",
          status: "offline",
          rating: 4.8,
          totalRides: 247
        };
        setDriverInfo(demoDriver);
        onLogin(true);
      } else {
        setError("Please enter your email and password");
      }
    } catch (err) {
      setError("Login failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-400 via-green-500 to-green-600 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Car className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Farezy Driver</h1>
          <p className="text-green-100">Your Partner Dashboard</p>
        </div>

        <div className="bg-white rounded-2xl shadow-2xl p-6">
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <input
                type="email"
                value={credentials.email}
                onChange={(e) => setCredentials({...credentials, email: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="driver@company.com"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={credentials.password}
                  onChange={(e) => setCredentials({...credentials, password: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent pr-12"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                <p className="text-red-600 text-sm">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-green-700 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <LogIn className="w-5 h-5" />
                  Sign In
                </>
              )}
            </button>
          </form>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h3 className="text-sm font-medium text-blue-800 mb-2">Demo Access</h3>
            <p className="text-xs text-blue-600">
              Enter any email and password to access the demo driver dashboard. 
              In production, this connects to your Farezy partner account.
            </p>
          </div>

          <div className="mt-6 text-center">
            <p className="text-xs text-gray-500">
              Part of the Farezy Partner Network
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
```

## 11. src/pages/Bookings.tsx
```typescript
import { ArrowLeft, Clock, MapPin, Phone } from "lucide-react";
import { useLocation } from "wouter";

interface BookingsProps {
  driverInfo: any;
}

export default function Bookings({ driverInfo }: BookingsProps) {
  const [, setLocation] = useLocation();

  const activeBookings = [
    {
      id: "BK001",
      pickup: "123 High Street, Leeds",
      dropoff: "Leeds Train Station",
      customer: "Sarah Johnson",
      phone: "07123456789",
      estimatedFare: 12.50,
      status: "en_route",
      time: "2 mins away"
    }
  ];

  const recentBookings = [
    {
      id: "BK002",
      pickup: "City Centre",
      dropoff: "Airport",
      fare: 25.00,
      status: "completed",
      time: "1 hour ago"
    },
    {
      id: "BK003", 
      pickup: "Shopping Mall",
      dropoff: "University",
      fare: 15.50,
      status: "completed",
      time: "3 hours ago"
    }
  ];

  return (
    <div className="p-4 pb-20">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => setLocation('/')}>
          <ArrowLeft className="w-6 h-6 text-gray-600" />
        </button>
        <h1 className="text-xl font-bold">Bookings</h1>
      </div>

      {/* Active Bookings */}
      {activeBookings.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-3">Active Trip</h2>
          {activeBookings.map((booking) => (
            <div key={booking.id} className="bg-green-50 border border-green-200 rounded-xl p-4 mb-4">
              <div className="flex justify-between items-start mb-3">
                <span className="text-sm font-medium text-green-800">#{booking.id}</span>
                <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                  {booking.time}
                </span>
              </div>
              
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  <span className="text-sm">{booking.pickup}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-3 h-3 text-red-500" />
                  <span className="text-sm">{booking.dropoff}</span>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium">{booking.customer}</p>
                  <p className="text-sm text-gray-600">£{booking.estimatedFare}</p>
                </div>
                <button className="bg-green-600 text-white p-2 rounded-full">
                  <Phone className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Recent Bookings */}
      <div>
        <h2 className="text-lg font-semibold mb-3">Recent Trips</h2>
        <div className="space-y-3">
          {recentBookings.map((booking) => (
            <div key={booking.id} className="bg-white border border-gray-200 rounded-xl p-4">
              <div className="flex justify-between items-start mb-2">
                <span className="text-sm font-medium text-gray-600">#{booking.id}</span>
                <span className="text-xs text-gray-500">{booking.time}</span>
              </div>
              
              <div className="space-y-1 mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span className="text-sm">{booking.pickup}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-2 h-2 text-red-500" />
                  <span className="text-sm">{booking.dropoff}</span>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <span className="font-semibold text-green-600">£{booking.fare}</span>
                <span className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded-full">
                  Completed
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
```

## 12. src/pages/Earnings.tsx
```typescript
import { ArrowLeft, PoundSterling, TrendingUp, Calendar } from "lucide-react";
import { useLocation } from "wouter";

interface EarningsProps {
  driverInfo: any;
}

export default function Earnings({ driverInfo }: EarningsProps) {
  const [, setLocation] = useLocation();

  const earningsData = {
    today: 45.50,
    week: 312.75,
    month: 1250.00,
    trips: {
      today: 8,
      week: 42,
      month: 178
    }
  };

  return (
    <div className="p-4 pb-20">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => setLocation('/')}>
          <ArrowLeft className="w-6 h-6 text-gray-600" />
        </button>
        <h1 className="text-xl font-bold">Earnings</h1>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-4 mb-6">
        <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-xl p-6 text-white">
          <div className="flex items-center gap-2 mb-2">
            <PoundSterling className="w-5 h-5" />
            <span className="text-green-100">Today's Earnings</span>
          </div>
          <p className="text-3xl font-bold">£{earningsData.today}</p>
          <p className="text-green-100 text-sm">{earningsData.trips.today} trips completed</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white border border-gray-200 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-4 h-4 text-blue-600" />
              <span className="text-sm text-gray-600">This Week</span>
            </div>
            <p className="text-xl font-bold text-gray-900">£{earningsData.week}</p>
            <p className="text-gray-500 text-xs">{earningsData.trips.week} trips</p>
          </div>

          <div className="bg-white border border-gray-200 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-purple-600" />
              <span className="text-sm text-gray-600">This Month</span>
            </div>
            <p className="text-xl font-bold text-gray-900">£{earningsData.month}</p>
            <p className="text-gray-500 text-xs">{earningsData.trips.month} trips</p>
          </div>
        </div>
      </div>

      {/* Recent Earnings */}
      <div>
        <h2 className="text-lg font-semibold mb-3">Recent Earnings</h2>
        <div className="space-y-3">
          {[
            { time: "2:30 PM", amount: 8.50, trip: "City Centre → Mall" },
            { time: "1:45 PM", amount: 12.00, trip: "Airport → Hotel" },
            { time: "12:15 PM", amount: 6.75, trip: "Station → Office" },
            { time: "11:30 AM", amount: 15.25, trip: "Home → University" }
          ].map((earning, index) => (
            <div key={index} className="bg-white border border-gray-200 rounded-xl p-4 flex justify-between items-center">
              <div>
                <p className="font-medium text-gray-900">{earning.trip}</p>
                <p className="text-sm text-gray-500">{earning.time}</p>
              </div>
              <span className="font-semibold text-green-600">£{earning.amount}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
```

## 13. src/pages/Profile.tsx
```typescript
import { ArrowLeft, User, Car, Star, LogOut, Settings, Phone, Mail } from "lucide-react";
import { useLocation } from "wouter";

interface ProfileProps {
  driverInfo: any;
  setAuth: (auth: boolean) => void;
}

export default function Profile({ driverInfo, setAuth }: ProfileProps) {
  const [, setLocation] = useLocation();

  const handleLogout = () => {
    setAuth(false);
  };

  return (
    <div className="p-4 pb-20">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => setLocation('/')}>
          <ArrowLeft className="w-6 h-6 text-gray-600" />
        </button>
        <h1 className="text-xl font-bold">Profile</h1>
      </div>

      {/* Driver Info Card */}
      <div className="bg-white border border-gray-200 rounded-xl p-6 mb-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
            <User className="w-8 h-8 text-green-600" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900">{driverInfo?.name || 'Driver Name'}</h2>
            <p className="text-gray-600">{driverInfo?.email || 'driver@company.com'}</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-900">{driverInfo?.totalRides || 247}</p>
            <p className="text-sm text-gray-600">Total Trips</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1">
              <Star className="w-4 h-4 text-yellow-500 fill-current" />
              <p className="text-2xl font-bold text-gray-900">{driverInfo?.rating || 4.8}</p>
            </div>
            <p className="text-sm text-gray-600">Rating</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-900">98%</p>
            <p className="text-sm text-gray-600">Accept Rate</p>
          </div>
        </div>
      </div>

      {/* Vehicle Info */}
      <div className="bg-white border border-gray-200 rounded-xl p-4 mb-6">
        <div className="flex items-center gap-2 mb-3">
          <Car className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold">Vehicle Information</h3>
        </div>
        <p className="text-gray-700">{driverInfo?.vehicle || 'Toyota Prius - ABC123'}</p>
        <p className="text-sm text-gray-500">{driverInfo?.company || 'Demo Taxi Co'}</p>
      </div>

      {/* Menu Options */}
      <div className="space-y-3">
        <button className="w-full bg-white border border-gray-200 rounded-xl p-4 flex items-center gap-3 text-left">
          <Settings className="w-5 h-5 text-gray-600" />
          <span className="font-medium">Settings</span>
        </button>

        <button className="w-full bg-white border border-gray-200 rounded-xl p-4 flex items-center gap-3 text-left">
          <Phone className="w-5 h-5 text-gray-600" />
          <span className="font-medium">Support</span>
        </button>

        <button className="w-full bg-white border border-gray-200 rounded-xl p-4 flex items-center gap-3 text-left">
          <Mail className="w-5 h-5 text-gray-600" />
          <span className="font-medium">Feedback</span>
        </button>

        <button 
          onClick={handleLogout}
          className="w-full bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-3 text-left text-red-600"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Sign Out</span>
        </button>
      </div>
    </div>
  );
}
```

The complete setup guide is now ready! You can:

1. **Create a new Repl** at replit.com using React + Vite template
2. **Copy all the files** from the DRIVER_APP_FILES.md guide
3. **Install dependencies** with `npm install`
4. **Access your separate driver app** at your new Repl's URL

The new design features:
- **Full-screen map** with simplified road pattern
- **Earnings display** at the top (like the $0.00 in your image)
- **Central GO button** for status control
- **Bottom status bar** showing online/offline state
- **Side controls** for additional features
- **Clean navigation** that hides on the main map view

This gives you a completely independent driver app that matches the layout style you requested.