# Complete Guide: Setting Up Taxi Company Registration & Booking System

## Overview
This guide explains how taxi companies can register with Farezy and start receiving bookings. The system includes company registration, admin approval, driver onboarding, and real-time booking management.

## 🏢 For Taxi Companies

### Step 1: Company Registration
1. **Visit Registration Page**: Go to `/partner-signup`
2. **Complete Application Form**:
   - Company details (name, address, contact info)
   - Operating information (area, fleet size, hours)
   - Pricing structure (base rate, per-km rate)
   - Legal documents (license number, insurance)
   - Service types offered
3. **Submit Application**: Status will be "Pending Review"

### Step 2: Admin Approval Process
- Admin reviews application at `/admin-dashboard`
- Application status: Pending → Approved/Rejected
- You'll receive notification of approval status
- Admin can add notes explaining decisions

### Step 3: Driver & Vehicle Registration
Once approved, register your drivers:
1. **Visit**: `/driver-management`
2. **Add Drivers**: For each driver, provide:
   - Personal details (name, phone, license)
   - Vehicle information (make, model, plate)
   - Upload required documents
3. **Driver Onboarding**: Drivers complete registration at `/driver-onboard`

### Step 4: Start Receiving Bookings
1. **Access Booking Dashboard**: `/booking-management`
2. **Monitor Real-Time Requests**: View incoming ride requests
3. **Submit Competitive Quotes**: Provide price and ETA estimates
4. **Assign Drivers**: Select available drivers for confirmed rides
5. **Track Performance**: Monitor bookings and driver activity

## 🛠️ For Platform Administrators

### Admin Dashboard Features (`/admin-dashboard`)
- **Application Review**: Approve/reject company applications
- **Partner Management**: View all registered taxi companies
- **Performance Monitoring**: Track platform usage statistics
- **Quality Control**: Review company ratings and compliance

### Admin Actions Required
1. **Review Applications**: Check company credentials and documents
2. **Verify Licenses**: Ensure legal compliance and insurance
3. **Set Operating Parameters**: Define service areas and requirements
4. **Monitor Performance**: Track booking success rates and quality

## 🚗 Driver Management System

### Driver Registration Process
1. **Partner Registration**: Company registers drivers in bulk
2. **Individual Onboarding**: Each driver completes personal registration
3. **Document Verification**: Upload license, insurance, vehicle docs
4. **Background Checks**: Admin can review driver applications
5. **Go Online**: Approved drivers can start accepting rides

### Real-Time Features
- **GPS Tracking**: Live driver location updates
- **Status Management**: Online/offline driver availability
- **Ride Assignment**: Automatic or manual driver assignment
- **Performance Tracking**: Driver ratings and statistics

## 📱 Booking Flow

### Customer Side
1. **Request Ride**: Customer submits pickup/destination
2. **Receive Quotes**: Multiple taxi companies provide estimates
3. **Select Provider**: Choose based on price, ETA, ratings
4. **Track Ride**: Real-time GPS tracking during trip
5. **Complete Payment**: Integrated payment processing

### Taxi Company Side
1. **Receive Request**: Real-time notification of new ride request
2. **Submit Quote**: Provide competitive price and arrival time
3. **Win Booking**: Customer selects your quote
4. **Assign Driver**: Allocate available driver to ride
5. **Complete Service**: Driver executes ride and gets paid

## 🔧 Technical Implementation

### Database Tables
- `partner_applications`: Company registration data
- `drivers`: Driver profiles and credentials
- `vehicles`: Vehicle information and documentation
- `ride_requests`: Customer ride requests
- `price_quotes`: Company bids on rides
- `ride_tracking`: Real-time ride status updates

### API Endpoints
- `POST /api/partner-signup`: Submit company application
- `GET /api/partner-applications`: Admin view applications
- `PUT /api/partner-applications/:id/review`: Approve/reject
- `POST /api/drivers`: Register new driver
- `GET /api/rides/requests`: View available ride requests
- `POST /api/price-quotes`: Submit competitive quote

### Real-Time Features
- **WebSocket Integration**: Live updates for bookings and tracking
- **GPS Tracking**: Real-time driver location broadcasts
- **Push Notifications**: Instant alerts for new requests
- **Live Dashboard**: Real-time booking management interface

## 🚀 Getting Started Quickly

### For New Taxi Companies
1. Complete registration form at `/partner-signup`
2. Wait for admin approval (typically 1-2 business days)
3. Register drivers and vehicles via `/driver-management`
4. Start monitoring bookings at `/booking-management`
5. Submit competitive quotes to win customers

### For Platform Admins
1. Access admin dashboard at `/admin-dashboard`
2. Review pending applications regularly
3. Approve legitimate taxi companies
4. Monitor platform performance and quality
5. Handle customer service issues

## 📊 Success Metrics

### Company Performance
- **Quote Win Rate**: Percentage of quotes that become bookings
- **Response Time**: Speed of quote submission
- **Customer Ratings**: Average ride satisfaction scores
- **Completion Rate**: Percentage of successful ride completions

### Platform Analytics
- **Active Companies**: Number of registered and active partners
- **Daily Bookings**: Total rides processed
- **Revenue Share**: Platform earnings from commissions
- **Growth Rate**: New company and driver registrations

## 🔒 Security & Compliance

### Required Documentation
- **Business License**: Valid taxi operating license
- **Insurance Certificate**: Comprehensive vehicle and liability coverage
- **Driver Licenses**: Valid commercial driving permits
- **Vehicle Registration**: Up-to-date vehicle documentation

### Data Protection
- **GDPR Compliance**: Secure handling of personal data
- **Payment Security**: PCI DSS compliant payment processing
- **Location Privacy**: Secure GPS data transmission
- **Document Verification**: Encrypted storage of sensitive documents

## 📞 Support

### For Taxi Companies
- **Registration Issues**: Contact admin support
- **Technical Problems**: Check troubleshooting guide
- **Payment Questions**: Review commission structure
- **Driver Training**: Access onboarding resources

### For Customers
- **Booking Problems**: Contact customer service
- **Payment Issues**: Review billing information
- **Safety Concerns**: Report immediately to admin
- **Service Quality**: Leave ratings and feedback

This comprehensive system enables taxi companies to easily register, get approved, onboard drivers, and start receiving bookings through a competitive quote-based marketplace.