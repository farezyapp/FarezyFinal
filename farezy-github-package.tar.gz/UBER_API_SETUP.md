# Uber API Configuration Guide (OAuth 2.0)

## Step 1: Create Uber Developer Account
1. Go to https://developer.uber.com/
2. Sign up or log in with your Uber account
3. Complete developer profile verification

## Step 2: Create a New App
1. Click "Create an App" in the dashboard
2. Fill in app details:
   - **App Name**: Farezy Price Comparison
   - **Description**: Ride price comparison and booking platform
   - **Redirect URL**: https://farezy.co.uk/auth/uber/callback

## Step 3: Get Required Credentials (OAuth 2.0)
Uber now uses OAuth 2.0 instead of server tokens:
- **Client ID**: Found in app dashboard
- **Client Secret**: Found in app dashboard

## Step 4: Configure OAuth Scopes
Your app will automatically request these scopes:
- `request` - Access ride request functionality
- `request_receipt` - Access ride receipts
- `history` - Access trip history
- `places` - Access saved places
- `profile` - Access user profile

## Step 5: Update Environment Variables
Set these two secrets:
- UBER_CLIENT_ID: [Your Client ID]
- UBER_CLIENT_SECRET: [Your Client Secret]

## How It Works
1. App uses client credentials flow to get access token
2. Access token is automatically refreshed when expired  
3. All API calls use Bearer token authentication

## Testing
Test with curl:
```bash
# Get access token
curl -X POST https://login.uber.com/oauth/v2/token \
  -d "client_id=YOUR_CLIENT_ID" \
  -d "client_secret=YOUR_CLIENT_SECRET" \
  -d "grant_type=client_credentials" \
  -d "scope=request request_receipt history places profile"

# Use token for API calls
curl -H "Authorization: Bearer ACCESS_TOKEN" \
  "https://api.uber.com/v1.2/products?latitude=37.7749295&longitude=-122.4194155"
```

## Common Issues:
- 401 Unauthorized: Invalid client credentials
- 403 Forbidden: App not approved for production use  
- Rate limiting: Too many requests per minute

## Current Status:
Ready for OAuth 2.0 client credentials setup.