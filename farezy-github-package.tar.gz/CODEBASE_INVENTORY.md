# Farezy Codebase Inventory

## Complete File Structure

### Frontend (client/)
```
client/
├── src/
│   ├── App.tsx                 # Main application component
│   ├── main.tsx               # React entry point
│   ├── index.css              # Global styles
│   ├── pwa.ts                 # PWA service worker config
│   ├── types.ts               # TypeScript type definitions
│   ├── components/
│   │   ├── ui/                # Shadcn/UI components (40+ files)
│   │   ├── ai-booking-panel.tsx
│   │   ├── company-search-modal.tsx
│   │   ├── desktop-header.tsx
│   │   ├── driver-tracking-map.tsx
│   │   ├── enhanced-map.tsx
│   │   ├── google-maps-wrapper.tsx
│   │   ├── location-autocomplete.tsx
│   │   ├── mobile-header.tsx
│   │   ├── price-comparison.tsx
│   │   ├── ride-booking.tsx
│   │   └── [20+ more components]
│   ├── pages/
│   │   ├── home.tsx           # Main homepage
│   │   ├── login.tsx          # User authentication
│   │   ├── signup.tsx         # User registration
│   │   ├── profile.tsx        # User profile management
│   │   ├── admin.tsx          # Admin dashboard
│   │   ├── driver-onboard.tsx # Driver registration
│   │   ├── about.tsx          # About page
│   │   ├── faq.tsx           # FAQ page
│   │   ├── privacy.tsx        # Privacy policy
│   │   ├── terms.tsx          # Terms of service
│   │   └── [10+ more pages]
│   ├── hooks/
│   │   ├── use-toast.ts       # Toast notifications
│   │   ├── useWebSocket.ts    # WebSocket communication
│   │   └── [5+ custom hooks]
│   └── lib/
│       ├── queryClient.ts     # TanStack Query setup
│       ├── utils.ts           # Utility functions
│       └── [Additional utilities]
├── public/
│   ├── manifest.json          # PWA manifest
│   ├── sw.js                  # Service worker
│   ├── icons/                 # App icons
│   └── [Static assets]
└── index.html                 # HTML entry point
```

### Backend (server/)
```
server/
├── index.ts                   # Express server entry point
├── db.ts                      # Database connection
├── storage.ts                 # Database operations (500+ lines)
├── routes.ts                  # API route definitions
├── vite.ts                    # Vite dev server integration
├── controllers/
│   ├── locationController.ts  # Location services
│   └── rideController.ts      # Ride management
├── services/
│   ├── auth.ts               # Authentication service
│   ├── email.ts              # Email services (SendGrid)
│   ├── aiBookingService.ts   # AI booking integration
│   ├── locationService.ts    # GPS and geocoding
│   ├── rideService.ts        # Ride comparison logic
│   └── uber.ts               # Uber API integration
├── middleware/
│   └── security.ts           # Security middleware
├── utils/
│   └── apiUtils.ts           # API utilities
└── mocks/
    └── rideData.ts           # Mock data for testing
```

### Shared Types (shared/)
```
shared/
└── schema.ts                  # Database schema (800+ lines)
    ├── Location tables
    ├── Service definitions
    ├── User accounts
    ├── Ride requests
    ├── Driver management
    ├── Vehicle registration
    ├── Analytics tracking
    └── [15+ database tables]
```

### Configuration Files
```
├── package.json              # Dependencies and scripts
├── package-lock.json         # Dependency lock file
├── tsconfig.json            # TypeScript configuration
├── vite.config.ts           # Vite build configuration
├── tailwind.config.ts       # Tailwind CSS setup
├── postcss.config.js        # PostCSS configuration
├── drizzle.config.ts        # Database ORM configuration
├── components.json          # Shadcn/UI configuration
├── .gitignore              # Git ignore rules
└── README.md               # Project documentation
```

## Key Statistics
- **Total Files**: 150+ source files
- **Lines of Code**: 15,000+ lines
- **Components**: 60+ React components
- **API Endpoints**: 25+ REST endpoints
- **Database Tables**: 15+ tables with relations
- **Languages**: TypeScript, JavaScript, CSS
- **Dependencies**: 50+ npm packages

## Feature Completeness
- ✅ User Authentication (Login/Signup/Verification)
- ✅ Real-time Ride Booking
- ✅ Google Maps Integration
- ✅ WebSocket Communication
- ✅ Driver Network Management
- ✅ Price Comparison Engine
- ✅ Progressive Web App (PWA)
- ✅ Admin Dashboard
- ✅ Email Services
- ✅ Database Operations
- ✅ Security Middleware
- ✅ Error Handling
- ✅ Responsive Design
- ✅ Real-time Tracking

## Current Status
**All files exist and are functional in the Replit workspace.**
**Application is live and operational with all features working.**